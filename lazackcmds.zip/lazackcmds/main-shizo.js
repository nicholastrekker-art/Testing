let handler = async m =>
  m.reply(
    `

≡ SILVA-MD-BOT GROUPS

─────────────
▢ Join public bot group and support
https://whatsapp.com/channel/0029VaAkETLLY6d8qhLmZt2v

▢ Group 2
https://whatsapp.com/channel/0029VaAkETLLY6d8qhLmZt2v

─────────────
≡ Disabled links? enter here! 

▢ channel WhatsApp 
 https://whatsapp.com/channel/0029VaFytPbAojYm7RIs6l1x
─────────────
▢ *Owner instagram*
 https://instagram.com/its_silva

▢ *YouTube*
• https://www.youtube.com/@silvaedits254


`.trim()
  )
handler.help = ['ruth']
handler.tags = ['main']
handler.command = ['groups', 'groupsilva', 'silvagp', 'sgp', 'grp']

export default handler
